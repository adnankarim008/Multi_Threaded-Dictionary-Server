package dictionary;

public class CommandWrapper {
    public String command;
    public Word word;
}
